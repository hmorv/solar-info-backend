const { evaluateSolarAlarms } = require('./services/alarmEvaluator');
const https = require('https');
const mysql = require('mysql2/promise');
const { parseStringPromise } = require('xml2js');

const dbConfig = {
  host: 'localhost',
  user: 'dxsun',
  password:
    'Los pajaros de plomo no vuelan tan bien como los de carne y hueso.',
  database: 'dxsun',
};

const url = 'https://www.hamqsl.com/solarxml.php';

async function fetchXML() {
  return new Promise((resolve, reject) => {
    https
      .get(url, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => resolve(data));
      })
      .on('error', reject);
  });
}

function parseIntOrNull(value) {
  return value !== undefined &&
    value !== null &&
    value !== '' &&
    /^\s*-?\d+\s*$/.test(String(value))
    ? parseInt(value, 10)
    : null;
}

function parseFloatOrNull(value) {
  return value !== undefined &&
    value !== null &&
    value !== '' &&
    /^\s*-?\d+(\.\d+)?(e[+-]?\d+)?\s*$/i.test(String(value))
    ? parseFloat(value)
    : null;
}

function trimOrNull(value) {
  return typeof value === 'string' ? value.trim() || null : value ?? null;
}

async function parseAndStore() {
  const xml = await fetchXML();
  const parsed = await parseStringPromise(xml, { explicitArray: false });

  const d = parsed.solar?.solardata || parsed.solar;

  if (!d) {
    throw new Error('XML inválido: no se encontró solar/solardata');
  }

  const conn = await mysql.createConnection(dbConfig);

  try {
    const [dbInfo] = await conn.query(`
      SELECT
        DATABASE() AS db,
        USER() AS user,
        @@hostname AS host,
        @@port AS port
    `);

    console.log('📌 DB info:', dbInfo[0]);

    await conn.beginTransaction();

    const reading = {
      solarFlux: parseFloatOrNull(d.solarflux),
      aIndex: parseIntOrNull(d.aindex),
      kIndex: parseIntOrNull(d.kindex),
      kIndexNt: trimOrNull(d.kindexnt),
      xRay: trimOrNull(d.xray),
      sunspots: parseIntOrNull(d.sunspots),
      heliumLine: parseFloatOrNull(d.heliumline),
      protonFlux: parseFloatOrNull(d.protonflux),
      electronFlux: parseIntOrNull(d.electonflux ?? d.electronflux),
      aurora: parseIntOrNull(d.aurora),
      normalization: parseFloatOrNull(d.normalization),
      latDegree: parseFloatOrNull(d.latdegree),
      solarWind: parseFloatOrNull(d.solarwind),
      magneticField: parseFloatOrNull(d.magneticfield),
    };

    const [result] = await conn.execute(
      `
      INSERT INTO solar_readings (
        updated,
        solar_flux,
        a_index,
        k_index,
        k_index_nt,
        x_ray,
        sunspots,
        helium_line,
        proton_flux,
        electron_flux,
        aurora,
        normalization,
        lat_degree,
        solar_wind,
        magnetic_field,
        geomag_field,
        signal_noise,
        fof2,
        muffactor,
        muf
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        trimOrNull(d.updated),
        reading.solarFlux,
        reading.aIndex,
        reading.kIndex,
        reading.kIndexNt,
        reading.xRay,
        reading.sunspots,
        reading.heliumLine,
        reading.protonFlux,
        reading.electronFlux,
        reading.aurora,
        reading.normalization,
        reading.latDegree,
        reading.solarWind,
        reading.magneticField,
        trimOrNull(d.geomagfield),
        trimOrNull(d.signalnoise),
        trimOrNull(d.fof2),
        trimOrNull(d.muffactor),
        trimOrNull(d.muf),
      ]
    );

    const readingId = result.insertId;

    if (!readingId) {
      throw new Error('No se obtuvo insertId al crear solar_readings');
    }

    console.log(`📌 solar_readings insertId: ${readingId}`);

    const calculatedBands = d.calculatedconditions ?? d.bandconditions;
    const bands = calculatedBands?.band || [];
    const bandArray = Array.isArray(bands) ? bands : bands ? [bands] : [];

    for (const band of bandArray) {
      await conn.execute(
        `
        INSERT INTO band_conditions (
          reading_id,
          band_name,
          time_of_day,
          current_condition
        )
        VALUES (?, ?, ?, ?)
        `,
        [
          readingId,
          band.$?.name || null,
          band.$?.time || null,
          band._ || null,
        ]
      );
    }

    const vhfSource = d.calculatedvhfconditions ?? d.vhfconditions;
    const vhfs = vhfSource?.phenomenon || [];
    const vhfArray = Array.isArray(vhfs) ? vhfs : vhfs ? [vhfs] : [];

    for (const pheno of vhfArray) {
      await conn.execute(
        `
        INSERT INTO vhf_conditions (
          reading_id,
          phenomenon_name,
          location,
          current_condition
        )
        VALUES (?, ?, ?, ?)
        `,
        [
          readingId,
          pheno.$?.name || null,
          pheno.$?.location || null,
          pheno._ || null,
        ]
      );
    }

    const [checkRows] = await conn.execute(
      `
      SELECT
        id,
        updated,
        fof2,
        muffactor,
        muf
      FROM solar_readings
      WHERE id = ?
      LIMIT 1
      `,
      [readingId]
    );

    console.log('📌 Insert check:', checkRows[0] || null);

    await conn.commit();

    console.log(
      `✅ Lectura guardada correctamente en dxsun.solar_readings (id ${readingId})`
    );

    await evaluateSolarAlarms(reading);
  } catch (error) {
    await conn.rollback();
    console.error('❌ Rollback ejecutado:', error.message);
    throw error;
  } finally {
    await conn.end();
  }
}

parseAndStore().catch((err) => {
  console.error('❌ Error:', err.message);
});